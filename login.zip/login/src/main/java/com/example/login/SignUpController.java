package com.example.login;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.ResourceBundle;

public class SignUpController implements Initializable {

    private Button button_signup;
    private Button button_login;

    private RadioButton rb_suscribe;
    private RadioButton rb_nosub;

    private TextField tf_username;
    private TextField tf_password;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ToggleGroup toggleGroup = new ToggleGroup();
        rb_suscribe.setToggleGroup(toggleGroup);
        rb_nosub.setToggleGroup(toggleGroup);

        button_signup.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
               String toggleName = ((RadioButton) toggleGroup.getSelectedToggle()).getText();

               if (!tf_username.getText().trim().isEmpty() && !tf_password.getText().trim().isEmpty()){
                   DBUtils.signUpUser(event, tf_username.getText(), tf_password.getText(), toggleName);

               }else{
                   System.out.println("Please fill in all information");
                   Alert alert = new Alert(Alert.AlertType.ERROR);
                   alert.setContentText("Please fill in all information");
                    alert.show();
               }

            }
        });

        button_login.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                DBUtils.changeScene(event, "hellow-view.fxml","Log in", null, null);
            }
        });
    }
}
