package com.example.login;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.EventObject;
public class LoggedInController implements Initializable {
    @FXML
    private Button button_logout;

    @FXML
    static Label label_welcome;
    @FXML Label label_red;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        button_logout.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                DBUtils.changeScene(event, "hello-view.fxml","title","null","null");

            }
        });

    }
    public static void setUserInformation(String username, String welcome){

        label_welcome.setText("Welcome"+ username+"!");

    }
}
